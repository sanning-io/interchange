// Producer enrolment — the "agents appear by anchoring" path.
//
// One org API key, no per-agent credential, no hand-rolled enrol script: the
// SDK proves possession of its OWN signing key to the control plane, and the
// control plane attributes anchors to whatever that signature proves. The API
// key authorizes the call; it never decides identity (control-plane#62/#65).
//
// The handshake is two calls:
//
//   POST <baseUrl>/api/v1/producer/challenge  → a single-use nonce
//   POST <baseUrl>/api/v1/producer/register   → nonce signed by the identity key
//
// Re-registering the SAME public key is an idempotent no-op server-side, which
// is what makes it safe to run on every boot. A DIFFERENT key for an existing
// producer is a rotation and additionally requires the same nonce signed by the
// OUTGOING key — otherwise a leaked org key could take over an identity that is
// already producing evidence.

import { bytesToHex, utf8 } from "@ar.io/proof";

import {
  EnrolmentFailedError,
  EnrolmentThrottledError,
  RotationUnauthorizedError,
} from "./errors.js";
import type { Signer } from "./types.js";

// Control-plane error codes we branch on by name. Everything else surfaces as
// EnrolmentFailedError carrying the code verbatim, so a caller can switch on
// something the SDK has not been taught yet.
const CP_ROTATION_UNAUTHORIZED = "PRODUCER_ROTATION_UNAUTHORIZED";
const CP_CHALLENGE_INVALID = "PRODUCER_CHALLENGE_INVALID";

export interface EnrolmentOptions {
  // Control-plane origin, no trailing slash — the same baseUrl the uploader
  // uses (`<baseUrl>/anchor`); producer routes live at `<baseUrl>/api/v1/producer`.
  baseUrl: string;
  apiKey: string;
  producerId: string;
  // The envelope identity key. Its public half IS the identity the control
  // plane attributes anchors to, so enrolment and signing MUST use one signer.
  signer: Signer;
  // Roster display name. Absent leaves whatever the roster already holds, so an
  // older SDK that never sends one cannot blank a name someone set.
  name?: string;
  // Supply ONLY when deliberately rotating: the retiring key, used to sign the
  // same nonce. Never populated automatically — a rotation is an intent, and
  // inferring it from a 403 is how an SDK silently steals an identity.
  previousSigner?: Signer;
  // Injectable seams (mirrors ArweaveUploader).
  fetchImpl?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  maxRetries?: number;
  retryBaseDelayMs?: number;
  random?: () => number;
}

export interface EnrolmentResult {
  producerId: string;
  publicKey: string;
  status: string;
  // True when this call replaced a different active key.
  rotated: boolean;
  // Present only on a rotation: how long the previous key stays valid, so a
  // rolling fleet knows when it must have finished cutting over.
  previousKeyValidUntil?: string;
}

interface CpErrorBody {
  error?: { code?: unknown; message?: unknown };
  code?: unknown;
  message?: unknown;
}

// The control plane's error envelope has moved shape before; read it
// defensively rather than assuming one nesting.
function readErrorCode(body: unknown): string | undefined {
  const b = body as CpErrorBody | null;
  const nested = b?.error?.code;
  if (typeof nested === "string") return nested;
  if (typeof b?.code === "string") return b.code;
  return undefined;
}

function readErrorMessage(body: unknown, fallback: string): string {
  const b = body as CpErrorBody | null;
  const nested = b?.error?.message;
  if (typeof nested === "string") return nested;
  if (typeof b?.message === "string") return b.message;
  return fallback;
}

/**
 * Enrol this producer's signing key, or confirm it is already enrolled.
 *
 * Idempotent by construction: re-registering the same key is a server-side
 * no-op, so the caller does not have to track whether it has run before.
 */
export async function ensureRegistered(
  opts: EnrolmentOptions,
): Promise<EnrolmentResult> {
  const base = opts.baseUrl.replace(/\/+$/, "");
  const fetchImpl = opts.fetchImpl ?? fetch;
  const sleep = opts.sleep ?? ((ms: number) => new Promise((r) => setTimeout(r, ms)));
  const maxRetries = opts.maxRetries ?? 2;
  const retryBaseDelayMs = opts.retryBaseDelayMs ?? 1000;
  const random = opts.random ?? Math.random;

  // Lowercase hex, both of them: the control plane's schemas are /^[0-9a-f]{64}$/
  // and /^[0-9a-f]{128}$/, so uppercase is refused as a malformed body rather
  // than as one of the typed enrolment errors. bytesToHex already emits
  // lowercase; the assertion is documentation for the next person.
  const publicKey = bytesToHex(await opts.signer.publicKey());

  const post = async (path: string, body: unknown): Promise<Response> =>
    fetchImpl(`${base}/api/v1/producer/${path}`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${opts.apiKey}`,
      },
      body: JSON.stringify(body),
    });

  // Enrolment is rate-limited per API KEY, and under the one-org-key model every
  // agent in the org shares that bucket — a fleet cold-starting together will
  // hit it. Honour Retry-After, and jitter so a restarted fleet does not
  // synchronise into the next window and throttle itself again.
  const throttleDelay = (res: Response, attempt: number): number => {
    const header = Number(res.headers.get("retry-after"));
    const base = Number.isFinite(header) && header > 0
      ? header * 1000
      : retryBaseDelayMs * 2 ** attempt;
    return base * (0.5 + random());
  };

  let lastDetail = "";
  const attempts = maxRetries + 1;

  for (let attempt = 0; attempt < attempts; attempt++) {
    // --- 1. challenge -------------------------------------------------
    const challengeRes = await post("challenge", { producer_id: opts.producerId });

    if (challengeRes.status === 429) {
      lastDetail = "enrolment rate limit on challenge";
      if (attempt < attempts - 1) {
        await sleep(throttleDelay(challengeRes, attempt));
        continue;
      }
      throw new EnrolmentThrottledError(opts.producerId, lastDetail);
    }
    if (!challengeRes.ok) {
      const body = await challengeRes.json().catch(() => null);
      if (challengeRes.status >= 500 && attempt < attempts - 1) {
        lastDetail = `challenge HTTP ${challengeRes.status}`;
        await sleep(retryBaseDelayMs * 2 ** attempt);
        continue;
      }
      throw new EnrolmentFailedError(
        challengeRes.status,
        readErrorCode(body),
        readErrorMessage(body, `challenge failed (HTTP ${challengeRes.status})`),
      );
    }

    const challengeBody = (await challengeRes.json()) as { challenge?: unknown };
    const challenge = challengeBody?.challenge;
    if (typeof challenge !== "string" || challenge.length === 0) {
      throw new EnrolmentFailedError(
        challengeRes.status,
        undefined,
        "challenge response did not contain a nonce",
      );
    }

    // --- 2. register --------------------------------------------------
    // The signed scope is the nonce's UTF-8 bytes — not a hash of them, and
    // not the JSON body.
    const nonceBytes = utf8(challenge);
    const signature = bytesToHex(await opts.signer.sign(nonceBytes));

    const registerBody: Record<string, unknown> = {
      producer_id: opts.producerId,
      public_key: publicKey,
      challenge,
      signature,
    };
    if (opts.name !== undefined) registerBody.name = opts.name;
    if (opts.previousSigner) {
      registerBody.previous_signature = bytesToHex(
        await opts.previousSigner.sign(nonceBytes),
      );
    }

    const registerRes = await post("register", registerBody);

    if (registerRes.ok) {
      const body = (await registerRes.json()) as {
        producer_id?: unknown;
        public_key?: unknown;
        status?: unknown;
        rotated?: unknown;
        previous_key_valid_until?: unknown;
      };
      return {
        producerId: typeof body.producer_id === "string" ? body.producer_id : opts.producerId,
        publicKey: typeof body.public_key === "string" ? body.public_key : publicKey,
        status: typeof body.status === "string" ? body.status : "active",
        rotated: body.rotated === true,
        ...(typeof body.previous_key_valid_until === "string"
          ? { previousKeyValidUntil: body.previous_key_valid_until }
          : {}),
      };
    }

    const errBody = await registerRes.json().catch(() => null);
    const code = readErrorCode(errBody);

    if (registerRes.status === 429) {
      lastDetail = "enrolment rate limit on register";
      if (attempt < attempts - 1) {
        await sleep(throttleDelay(registerRes, attempt));
        continue;
      }
      throw new EnrolmentThrottledError(opts.producerId, lastDetail);
    }

    // A nonce is single-use and expires. Losing the race is ordinary, not an
    // error worth surfacing — take a fresh one. Distinct from the 403s below,
    // which mean the caller is not entitled and retrying changes nothing.
    if (code === CP_CHALLENGE_INVALID && attempt < attempts - 1) {
      lastDetail = "challenge expired or already used";
      continue;
    }

    // The identity is already held by a different key. Retrying as a fresh
    // enrolment would be an attempt to seize it, so this is terminal and loud.
    if (code === CP_ROTATION_UNAUTHORIZED) {
      throw new RotationUnauthorizedError(opts.producerId);
    }

    if (registerRes.status >= 500 && attempt < attempts - 1) {
      lastDetail = `register HTTP ${registerRes.status}`;
      await sleep(retryBaseDelayMs * 2 ** attempt);
      continue;
    }

    throw new EnrolmentFailedError(
      registerRes.status,
      code,
      readErrorMessage(errBody, `registration failed (HTTP ${registerRes.status})`),
    );
  }

  throw new EnrolmentFailedError(0, undefined, `enrolment exhausted ${attempts} attempts: ${lastDetail}`);
}
