// Typed error family. The PRD makes one error first-class above all others:
// "wallet out of funds" with concrete funding instructions — the first
// failure a developer hits must be a conversion point, not a stack trace.

export type AnchorErrorCode =
  | "FUNDING_EXHAUSTED"
  | "UPLOAD_REJECTED"
  | "UPLOAD_FAILED"
  | "TXID_MISMATCH"
  | "PRODUCTION_CONFIG"
  | "CONTENT_RETENTION"
  | "ENROLMENT_FAILED"
  | "ENROLMENT_THROTTLED"
  | "ROTATION_UNAUTHORIZED";

export class AnchorError extends Error {
  constructor(
    readonly code: AnchorErrorCode,
    message: string,
  ) {
    super(message);
    this.name = new.target.name;
  }
}

export class FundingExhaustedError extends AnchorError {
  constructor(
    readonly status: number,
    detail: string,
  ) {
    super(
      "FUNDING_EXHAUSTED",
      `The upload service rejected the anchor for insufficient funds (HTTP ${status}). ` +
        `${detail ? detail + " " : ""}` +
        "Dev-mode free-tier wallets cover only small uploads and run dry. To fund: " +
        "use a funded upload wallet, or move to production credentials " +
        "(a funded, whitelisted wallet) via Sanning — " +
        "createAnchorer({ environment: \"production\", signer, wallet, subject }).",
    );
  }
}

export class UploadRejectedError extends AnchorError {
  constructor(
    readonly status: number,
    detail: string,
  ) {
    super("UPLOAD_REJECTED", `The upload service rejected the data item (HTTP ${status}): ${detail}`);
  }
}

export class UploadFailedError extends AnchorError {
  constructor(
    readonly attempts: number,
    detail: string,
  ) {
    super(
      "UPLOAD_FAILED",
      `Upload failed after ${attempts} attempt(s): ${detail}. ` +
        "Transient upstream or network fault — safe to retry the anchor call.",
    );
  }
}

export class TxIdMismatchError extends AnchorError {
  constructor(
    readonly predicted: string,
    readonly returned: string,
  ) {
    super(
      "TXID_MISMATCH",
      `The upload service returned TX ID ${returned} but the data item's signature derives ${predicted}. ` +
        "This should never happen with an honest upstream; treat the upload as suspect.",
    );
  }
}

export class ProductionConfigError extends AnchorError {
  constructor(missing: string[]) {
    super(
      "PRODUCTION_CONFIG",
      `createAnchorer({ environment: "production" }) requires explicit ${missing.join(", ")}. ` +
        "Production structurally refuses auto-generated secrets — dev-mode identities and " +
        "auto-minted wallets cannot reach it. Obtain production credentials (API key, " +
        "registered signing key, funded wallet) via Sanning.",
    );
  }
}

// Content retention (T9 Phase 2). Thrown when a configured LogStore's put()
// fails under STRICT retention (onRetentionError: "skip-anchor", the default):
// the event is deliberately NOT anchored, because an anchored-but-unretained
// event is precisely the unverifiable failure a LogStore exists to prevent.
// The drop is loud (this throw / a rejected receipt) AND enumerable (in batch
// mode the event's add()-time sink intent row never gets a proof), never
// silent. `cause` is the original put() failure.
export class RetentionError extends AnchorError {
  constructor(
    readonly eventId: string,
    readonly cause: unknown,
  ) {
    super(
      "CONTENT_RETENTION",
      `content retention failed for event ${eventId}: logStore.put() rejected ` +
        `(${cause instanceof Error ? cause.message : String(cause)}). Under strict retention ` +
        `(onRetentionError: "skip-anchor") this event was NOT anchored — refetch its content and ` +
        `re-anchor (it is enumerable via its sink intent row / proof-null), or configure ` +
        `onRetentionError: "anchor-anyway-flag" to anchor best-effort with contentStored:false.`,
    );
  }
}

// --- Producer enrolment (control-plane#62/#65) --------------------------------
//
// Enrolment is where a developer first meets the control plane, so these three
// are split by what the caller should DO, not by HTTP status. Two of them are
// 403s that mean opposite things, which is exactly why "handle 403" is not a
// strategy.

// Terminal enrolment failure. Carries the control plane's own error code
// verbatim so a caller can branch on a code this SDK has not been taught yet
// (PRODUCER_POP_FAILED, PRODUCER_ID_KEY_MISMATCH, PRODUCER_REGISTRATION_CONFLICT,
// SCOPE_NOT_ALLOWED, …) rather than parsing a message.
export class EnrolmentFailedError extends AnchorError {
  constructor(
    readonly status: number,
    readonly controlPlaneCode: string | undefined,
    detail: string,
  ) {
    super(
      "ENROLMENT_FAILED",
      `Producer enrolment failed${status ? ` (HTTP ${status}` : " ("}` +
        `${controlPlaneCode ? `, ${controlPlaneCode}` : ""}): ${detail}. ` +
        "Check that the API key carries the producer:enroll scope, that its org owns this " +
        "producer id, and that controlPlane.baseUrl points at the control plane origin " +
        "(not the /anchor front).",
    );
  }
}

// The identity exists and a DIFFERENT key already holds it. Deliberately not
// retryable: re-running enrolment here would be an attempt to take over an
// identity that is already producing evidence, which is the exact thing the
// outgoing-key signature requirement exists to prevent. Surfacing it beats
// silently succeeding under someone else's name.
export class RotationUnauthorizedError extends AnchorError {
  constructor(readonly producerId: string) {
    super(
      "ROTATION_UNAUTHORIZED",
      `Producer "${producerId}" is already registered under a different signing key. ` +
        "This is a key ROTATION, and it must be authorized by the key being retired — " +
        "not by the API key. Either point this anchorer at the existing signing key, or, " +
        "if you are intentionally rotating, pass the retiring key as " +
        "controlPlane.previousSigner so it can counter-sign the challenge. " +
        "If the old key is genuinely lost, rotate from the console instead " +
        "(a human break-glass, by design).",
    );
  }
}

// Enrolment is rate-limited per API KEY. Under one-org-key-per-fleet that
// bucket is shared by every agent in the org, so a fleet cold-starting together
// is the expected way to hit this — the message says so, because "429" alone
// sends people looking for a bug in their own code.
export class EnrolmentThrottledError extends AnchorError {
  constructor(
    readonly producerId: string,
    detail: string,
  ) {
    super(
      "ENROLMENT_THROTTLED",
      `Producer enrolment for "${producerId}" was rate-limited after all retries (${detail}). ` +
        "The enrolment limit is per API KEY, so every agent sharing one org key shares one " +
        "bucket — a fleet starting together can exhaust it. Stagger agent startup, or enrol " +
        "once out-of-band and reuse the registered signing key.",
    );
  }
}
